export class CreateProductDto {
    id: string;
    image: string;
    name: string;
    price: number;
    description: string;
    rating: string;


}

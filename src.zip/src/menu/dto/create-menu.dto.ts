export class CreateMenuDto {}

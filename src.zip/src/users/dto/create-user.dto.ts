export class CreateUserDto {
    address: string;
    receiveEmails: boolean;
    fullName: string;
    username: string;
    password: string;
}
